import { Container } from "react-bootstrap";

const Footer = () => {
    return (
        <Container fluid className="bg-dark text-white text-center py-3">
            <p>Created by Phan Duong Dinh</p>
        </Container>
    )
}

export default Footer
