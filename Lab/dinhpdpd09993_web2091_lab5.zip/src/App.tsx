import './App.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import Bai2 from './Lab5/Bai2'
import Bai3 from './Lab5/Bai3'
import Bai4 from './Lab5/Bai4'
import Bai5 from './Lab5/Bai5'

function App() {
    return (
        <>
            <Bai2></Bai2>
            <Bai3></Bai3>
            <Bai4></Bai4>
            <Bai5></Bai5>
        </>
    )
}

export default App
