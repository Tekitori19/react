import './App.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import Bai1 from './Lab7/Bai1'
import Bai2 from './Lab7/Bai2'
import Bai3 from './Lab7/Bai3'
import Bai4 from './Lab7/Bai4';

function App() {
    return (
        <>
            <Bai1></Bai1>
            <Bai2></Bai2>
            <Bai3></Bai3>
            <Bai4></Bai4>
        </>
    )
}

export default App
