const Demo = () => {
    return (
        <>
            <div className="intro">
                <h1>Welcome to my website!</h1>
            </div>
            <p className="summary">
                You can find my thoughts here.
                <br></br>
                <b>And</b> <i>pictures</i> of scientists!
            </p>
        </>
    )
}

export default Demo
